#include "diagnostics.h"

Diagnostics::Diagnostics(QObject *parent) :
    QObject(parent)
{
}
