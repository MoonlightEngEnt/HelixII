#include "settings.h"

Settings::Settings(QObject *parent) :
    QObject(parent)
{
}
